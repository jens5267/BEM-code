# -*- coding: utf-8 -*-
"""
Created on Thu Oct 25 11:44:37 2018

@author: Jens Reichwein
"""

import matplotlib.pyplot as plt
import numpy as np

def airfoil_polars():
    family  = 'NACA'
    family2 = 'S'
    family3 = 'SG'
    
    series = [2418]#2408,2412,2415,2418,4408,4412,4415,4418]
    series2 = [822, 1210, 2091, 4061, 4180, 4320]
    series3 = [6040,6041,6042,6043]
    
    airfoils = []
    count = 0
    for number in series:
        airfoils.append(family + '_' + str(number))
        
#    for number2 in series2:
#        airfoils.append(family2 + str(number2))
        
#    airfoils.append('SD7034')
#     
#    for number3 in series3:
#        airfoils.append(family3 + str(number3))
    reynolds = []
    for rey in range(5):
        reynolds.append(50+rey*5)
    
    #reynolds    = [50,55,100]


    for airfoil in airfoils:
        for r in reynolds:
            Alpha       = []
            c_L         = []
            c_D         = []
            L2D         = []
            max_L2D     = []
            AoA         = []
            count +=1
            
            path            = airfoil 
            link = str(path) +'/Montgomerie/'+ '/'+ str(path) + '_T1_Re' + str('{:.3f}'.format((int(r)/1000))) + '_M0.00_N9.0_360_M.dat'
            print(link)
            with open(link, 'r') as fp:
                for i in range (14):
                    next(fp)
                data = fp.read()

                for line in data.splitlines():
                    temp    = line.split()
                    if temp:                
                        alpha   = eval(temp[0])
                        cl      = eval(temp[1])
                        cd      = eval(temp[2])
                        
                        c_L.append(cl)
                        c_D.append(cd)
                        Alpha.append(alpha)
                        
                        l2d = cl/cd
                        L2D.append(l2d)
                        
                    else:
                        break
                    
        position = L2D.index(max(L2D))
        AoA.append(Alpha[position])
        max_l2d = max(L2D)
        max_L2D.append(max_l2d)
    ###############################################################################
        print('Airfoil {:d}: {:s}'.format(count, airfoil))
        print('{:>8s} {:>8s} {:>8s}'.format('max L/D','alpha', 'Re'))
#        for i in range(len(reynolds)):
#            print('{:8.3f} {:8.3f}  {:8.3f}'.format((max_L2D[i]), AoA[i], reynolds[i]))
        print((max_L2D), (max_l2d))
airfoil_polars()